import pattern

a = pattern.Checker(250, 25)
a.show()
#b = pattern.Circle(1800, 300, (900, 300))
#b.show()
#c = pattern.Spectrum(400)
#c.show()

